import React, { useState, useEffect } from 'react';
import api from '../api';
import ItemForm from './ItemForm';

export default function Dashboard() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    const fetchItems = async () => {
      const res = await api.get('/items');
      setItems(res.data);
    };
    fetchItems();
  }, []);

  const handleDelete = async (id) => {
    await api.delete(`/items/${id}`);
    setItems(items.filter(item => item._id !== id));
  };

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <ItemForm onAdd={(item) => setItems([item, ...items])} />
      <ul>
        {items.map(item => (
          <li key={item._id}>
            {item.sortNo} - <button onClick={() => handleDelete(item._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
