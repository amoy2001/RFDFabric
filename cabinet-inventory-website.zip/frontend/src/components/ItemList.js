import React, { useState, useEffect } from 'react';
import api from '../api';

export default function ItemList() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchItems = async () => {
      const res = await api.get('/items', { params: { search } });
      setItems(res.data);
    };
    fetchItems();
  }, [search]);

  return (
    <div>
      <h1>Cabinet Inventory</h1>
      <input
        type="text"
        placeholder="Search by Sort No"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <ul>
        {items.map(item => (
          <li key={item._id}>
            {item.sortNo} - {item.metre}m - Column {item.columnNo} - Received on {new Date(item.receiveDate).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
