import React, { useState } from 'react';
import api from '../api';

export default function ItemForm({ onAdd }) {
  const [formData, setFormData] = useState({ sortNo: '', metre: '', columnNo: '', receiveDate: '', remarks: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await api.post('/items', formData);
    onAdd(res.data);
    setFormData({ sortNo: '', metre: '', columnNo: '', receiveDate: '', remarks: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="Sort No" value={formData.sortNo} onChange={(e) => setFormData({...formData, sortNo: e.target.value})} required />
      <input placeholder="Metre" type="number" value={formData.metre} onChange={(e) => setFormData({...formData, metre: e.target.value})} required />
      <input placeholder="Column No" value={formData.columnNo} onChange={(e) => setFormData({...formData, columnNo: e.target.value})} />
      <input placeholder="Receive Date" type="date" value={formData.receiveDate} onChange={(e) => setFormData({...formData, receiveDate: e.target.value})} required />
      <input placeholder="Remarks" value={formData.remarks} onChange={(e) => setFormData({...formData, remarks: e.target.value})} />
      <button type="submit">Add Item</button>
    </form>
}
