# Cabinet Inventory Management Website

## Description
This project provides a full-stack implementation of a Cabinet Inventory Management System.

## Setup
1. Clone the repository.
2. Backend:
   - Navigate to `backend/`
   - Install dependencies: `npm install`
   - Create a `.env` based on `.env.example`
   - Run: `npm run dev`
3. Frontend:
   - Navigate to `frontend/`
   - Install dependencies: `npm install`
   - Run: `npm start`

## Deployment
- Backend: Deploy on Render.com as a Node.js service.
- Frontend: Deploy on Render.com as a static site.
