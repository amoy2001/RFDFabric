const mongoose = require('mongoose');

const ItemSchema = new mongoose.Schema({
  sortNo: { type: String, required: true, unique: true },
  metre: { type: Number, required: true },
  columnNo: { type: String },
  receiveDate: { type: Date, required: true },
  remarks: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Item', ItemSchema);
