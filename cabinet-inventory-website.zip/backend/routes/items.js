const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const auth = require('../middleware/auth');

// GET /api/items?search=sortNo
router.get('/', async (req, res) => {
  const { search } = req.query;
  const filter = search ? { sortNo: new RegExp(search, 'i') } : {};
  const items = await Item.find(filter).sort({ receiveDate: -1 });
  res.json(items);
});

// POST /api/items
router.post('/', auth, async (req, res) => {
  const newItem = new Item(req.body);
  await newItem.save();
  res.status(201).json(newItem);
});

// PUT /api/items/:id
router.put('/:id', auth, async (req, res) => {
  const updated = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// DELETE /api/items/:id
router.delete('/:id', auth, async (req, res) => {
  await Item.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
